<footer class="footer">
    <div class="d-sm-flex justify-content-center justify-content-sm-between">
        <span class="float-none float-sm-end d-block mt-1 mt-sm-0 text-center">Copyright © 2024. All rights reserved.</span>
    </div>
</footer>
<!-- plugins:js -->
<script src="/kygui/src/admin/assets/vendors/js/vendor.bundle.base.js"></script>
<script src="/kygui/src/admin/assets/vendors/bootstrap-datepicker/bootstrap-datepicker.min.js"></script>
<!-- endinject -->
<!-- Plugin js for this page -->
<script src="/kygui/src/admin/assets/vendors/chart.js/Chart.min.js"></script>
<script src="/kygui/src/admin/assets/vendors/progressbar.js/progressbar.min.js"></script>
<!-- End plugin js for this page -->
<!-- inject:js -->
<script src="/kygui/src/admin/assets/js/off-canvas.js"></script>
<script src="/kygui/src/admin/assets/js/hoverable-collapse.js"></script>
<!-- endinject -->
<!-- Custom js for this page-->
<script src="/kygui/src/admin/assets/js/jquery.cookie.js" type="text/javascript"></script>
<script src="/kygui/src/admin/assets/js/dashboard.js"></script>
<script src="/kygui/src/admin/assets/js/proBanner.js"></script>
<script src="/kygui/src/admin/assets/js/postTour.js"></script>
<script src="/kygui/src/admin/lib/xlsx.js"></script>

</script>